const uri="mongodb+srv://dev:Debesh4632@cluster0.i7rl8.mongodb.net/ems?retryWrites=true&w=majority&appName=Cluster0"
export default uri;
